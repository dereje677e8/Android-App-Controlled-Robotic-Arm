package com.example.roboece;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.hp.bluetoothjhr.BluetoothJhr;

public class MainActivity2 extends AppCompatActivity {
    BluetoothJhr bluetoothJhr;
    SeekBar values,values_wrist;
    TextView textvalue,textvalue2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        values = (SeekBar)findViewById(R.id.val);
        textvalue = (TextView)findViewById(R.id.textvalue);

        values_wrist = (SeekBar)findViewById(R.id.val2);
        textvalue2 = (TextView)findViewById(R.id.textvalue2);


        bluetoothJhr = new BluetoothJhr(MainActivity.class,this);


        values.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                String valueText = String.valueOf(i);
                bluetoothJhr.Tx("s"+valueText);
                textvalue.setText("values ="+valueText);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        values_wrist.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

                String valueText2 = String.valueOf(i);
                bluetoothJhr.Tx("b"+valueText2);
                textvalue2.setText("values_wrist ="+valueText2);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }


    @Override
    public void onResume(){
        super.onResume();
        bluetoothJhr.ConectaBluetooth();
    }
    @Override
    public void onPause(){
        super.onPause();
    }

}